#ifndef _CALC_RESISTANCE_H_
#define _CALC_RESISTANCE_H_

float calc_resistance(int count, char conn, float *array);

#endif


