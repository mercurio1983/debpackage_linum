#ifndef CALC_POWER_H
#define E_RESISTANCE_H

float calc_power_r(float volt, float resistance);
float calc_power_i(float volt, float current);

#endif