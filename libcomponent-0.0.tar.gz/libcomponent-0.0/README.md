# lin_um - lab6 Bibliotek

# libresistance.so
# libpower.so
# libcomponent.so
